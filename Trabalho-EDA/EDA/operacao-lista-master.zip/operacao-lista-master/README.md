# operacao-lista

ver 1
