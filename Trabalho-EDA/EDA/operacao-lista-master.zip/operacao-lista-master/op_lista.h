#include "lista.h"
#define ERRO_MEMORIA -1

void adiciona(LDE *l1, LDE *l2, LDE *l3);
void multiplica(LDE *l1, LDE *l2, LDE *l3);