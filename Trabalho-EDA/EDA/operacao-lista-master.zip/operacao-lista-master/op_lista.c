#include "op_lista.h"

int sobra = 0;


void adiciona(LDE * l1, LDE * l2, LDE * l3){
	/*
	Chegar at� o final da L1 e L2 recursivamente para fazer uma pilha implicita

	adicionar info das listas junto com sobra

	criar um Elemento para cada soma de l1 e l2 (junto com a sobra) e inserir no inicio da lista;
	
	*/

	
	
}

void multiplica(LDE * l1, LDE * l2, LDE * l3){

}
